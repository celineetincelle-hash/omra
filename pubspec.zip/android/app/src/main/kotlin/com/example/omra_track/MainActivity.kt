package com.example.omra_track

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
