class Constants {
  static const String gpsTraceAccessToken = "YOUR_GPS_TRACE_ACCESS_TOKEN";
  static const String googleMapsApiKey = "YOUR_GOOGLE_MAPS_API_KEY";
}


